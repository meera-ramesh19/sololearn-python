from django import template

register = template.Library()

@register.filter
def formatter(value):
    value = value.replace("_"," ")
    value = value.capitalize()
    return value
