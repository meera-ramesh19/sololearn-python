from django.apps import AppConfig


class FlipkartConfig(AppConfig):
    name = 'flipkart'
