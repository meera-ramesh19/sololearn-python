from django.shortcuts import render, HttpResponse
from .forms import FeedbackForm

# Create your views here.
def feedback(request):
    if request.method == 'GET':
        form = FeedbackForm
        return render(request,'feedback.html',{
            'form': form,
        })

    elif request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse("Saved!")

